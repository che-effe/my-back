	// creating Raphael log
					var totalHeight = 200;
					var logSpace = new Raphael(document.getElementById('log'), 588, 588);
					var goodPos = logSpace.circle(300, 300, 70);
						goodPos.attr({fill: 'r#925024-#c0692f:70-#cd9b54', stroke: 'none'});
					var goodPosSize = 2;
					var PoorPos = logSpace.circle(300, 300, 30);
						PoorPos.attr({fill: 'r(0.3, 0.3)#5ac0ee-#2f5287:60-#173158', stroke: 'none'});
					var PoorPosSize = 2;
					
                var disclaimer = document.getElementById("disclaimer")
            	var coach = document.getElementById("coach");
            	var threshgo = document.getElementById("threshold");
            	var chart = document.getElementById("log")
            //coach.className = 'move';
            //console.log('coach class added');
            //threshgo.className = 'go';
            //console.log('thresh class added');
            //chartin.className = 'shoo';
            //console.log('thresh class added');
				
			function disclaimerGo(){
				disclaimer.className = '';
				disclaimer.className = 'clear';
				console.log('clear class added');
				enterCoach();
			}
			function enterCoach(){
				goodPosSize = 2;
				PoorPosSize = 2;
				chart.className = '';
				coach.className = 'move';
				threshgo.className = 'go';
                console.log('coach class added');
                goodPos.animate({r: goodPosSize}, 500, '<>');
                PoorPos.animate({r: PoorPosSize}, 500, '<>');
                }
            function enterChart(){
            	threshgo.className = '';
            	coach.className = '';
				chart.className = 'shoo';
                console.log('Chart class added');
                goodPosSize = 280;
                PoorPosSize = 200;
                goodPos.animate({r: goodPosSize}, 1000, '<>');
				PoorPos.animate({r: PoorPosSize}, 1200, '<>');
                }
            function enterDir(){
				coach.className = '';
                console.log('coach class removed');
            }		
							
							
					
					
					
				
