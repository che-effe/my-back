//start app when the DOM is fully loaded
jQuery(document).ready(function() {

var appStartTime = 0,
	goodPostureTime = 0,
	badPostureTime = 0,
	appTimePercentage = 0,
	goodPosturePercentage = 0,
	badPosturePercentage = 0;

var logSpace = new Raphael(document.getElementById('log'), 588, 588),
	goodPos = logSpace.circle(300, 300, 70),
	goodPosSize = 2,
	PoorPos = logSpace.circle(300, 300, 30),
	PoorPosSize = 2;
	
	
//create system variables
var disclaimer = document.getElementById("disclaimer"),
	coach = document.getElementById("coach"),
	threshgo = document.getElementById("threshold"),
	chart = document.getElementById("log"),
	buzzer = document.getElementById("player"),
	chartBtn = document.getElementById("chartBtn"),
	coachBtn = document.getElementById("coachBtn"),
	directionsBtn = document.getElementById("directionsBtn"),
	skipBtn = document.getElementById("skipBtn");

var badPostureToggle = false;

var posture = document.getElementById('moCalcTiltLR').value;
    

setInterval(startTimers, 500);

function startTimers() {
	appStart();
	//goodPosture();
	//badPosture();
	setPercentages();
	if (posture > 20 || posture < -20){
	badPostureTime += 1;
	}
	else{
		goodPostureTime += 1;
	}
	}

function appStart() {
	appStartTime += 1;
}

//function goodPosture() {
	//if(!badPostureToggle) { goodPostureTime += 1; }
//}

//function badPosture() {
	//if(badPostureToggle) { badPostureTime += 1; }
//}

function setPercentages() {

	appTimePercentage = (appStartTime/appStartTime)/.01,
	goodPosturePercentage = (goodPostureTime/appStartTime)/.01,
	badPosturePercentage = (badPostureTime/appStartTime)/.01;

	console.log('App Runtime Percentage: ' +  appTimePercentage + '%');
	console.log('Good Posture Percentage: ' +  Math.round(goodPosturePercentage) + '%');
	console.log('Bad Posture Percentage: ' +  Math.round(badPosturePercentage) + '%');
	
}

function onBadPosture() {
	badPostureToggle = true;
}

function onGoodPosture() {
	badPostureToggle = false;
}

    
    // creating Raphael log
    function drawChart() {		
		badPosT = logSpace.text(100, 90,'Poor Posture: ' +  Math.round(badPosturePercentage) + '%');	
		badPosT.attr({fill: '#ffffff', 'font-size':20, 'font-family':'Monaco'});
		logSpace.path("M20 105 L180 105").attr({stroke:'#ffffff', 'stroke-width' : 1});

		GoodPosT = logSpace.text(450, 50,'Good Posture: ' +  Math.round(goodPosturePercentage) + '%');
		GoodPosT.attr({fill: '#ffffff', 'font-size':20, 'font-family':'Monaco'});
		logSpace.path("M420 65 L600 65").attr({stroke:'#ffffff', 'stroke-width' : 1});
		logSpace.circle(500, 75, 10).attr({fill: '#ffffff', stroke: 'none'});
		logSpace.path("M500 75 L500 120").attr({stroke:'#ffffff', 'stroke-width' : 1});
		logSpace.circle(500, 120, 10).attr({fill: '#ffffff', stroke: 'none'});
		
		BadLine = logSpace.path("M100 200 L300 300");
		BadLine.attr({stroke:'#ffffff', 'stroke-width' : 1});
		logSpace.circle(300, 300, 10).attr({fill: '#ffffff', stroke: 'none'});
		logSpace.circle(100, 200, 10).attr({fill: '#ffffff', stroke: 'none'});
		logSpace.path("M100 200 L100 115").attr({stroke:'#ffffff', 'stroke-width' : 1});
		logSpace.circle(100, 115, 10).attr({fill: '#ffffff', stroke: 'none'});
		PoorPos.attr({fill: 'r(0.3, 0.3)#5ac0ee-#2f5287:60-#173158', stroke: 'none'});
		goodPos.attr({fill: 'r#925024-#c0692f:70-#cd9b54', stroke: 'none'});
	}
	
	
	jQuery('#chartBtn').click(enterChart);
	jQuery('#coachBtn').click(enterCoach);
	jQuery('#skipBtn').click(disclaimerGo);
	
	// Functions for the app
			function disclaimerGo(){
			 	buzzer.play();
				disclaimer.className = '';
				disclaimer.className = 'clear';
				console.log('clear class added');
				enterCoach();
				
			}
			function enterCoach(){
				goodPosSize = 2;
				PoorPosSize = 2;
				chart.className = '';
				coach.className = 'move';
				threshgo.className = 'go';
                console.log('coach class added');
                goodPos.animate({r: goodPosSize}, 500, '<>');
                PoorPos.animate({r: PoorPosSize}, 500, '<>');
                }
            function enterChart(){
            	threshgo.className = '';
            	coach.className = '';
				chart.className = 'shoo';
                console.log('Chart class added');
                goodPosSize = 280;
                PoorPosSize = badPosturePercentage * goodPosSize ;
                //alert(badPosturePercentage);
                //PoorPosSize = 150;
                goodPos.animate({r: goodPosSize}, 1000, '<>');
				PoorPos.animate({r: PoorPosSize}, 1200, '<>');
				drawChart();
                }
            function enterDir(){
				coach.className = '';
                console.log('coach class removed');
            }
});

